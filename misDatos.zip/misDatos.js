const book = {
    titulo : "Frieren", 
    autor : "Mangaka", 
    fecha : "2020", 
    url : "xxxxxxxxx"
}

const misDatos = ["Pablo Chay", 23, true, "06 07 2023"];